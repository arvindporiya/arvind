<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
CREATE TABLE `storelocator_category` (
	`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Category Id',
	`name` VARCHAR(255) NULL DEFAULT NULL COMMENT 'Category Name',
	PRIMARY KEY (`id`)
)
COMMENT='storelocator_category'
COLLATE='utf8_general_ci'
ENGINE=InnoDB
;
CREATE TABLE `storelocator_state` (
	`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;
CREATE TABLE `storelocator_city` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;
CREATE TABLE `storelocator_area` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;
CREATE TABLE `storelocator_locator` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`category_id` INT(10) UNSIGNED NOT NULL,
	`state_id` INT(10) UNSIGNED NOT NULL,
	`city_id` INT(10) NOT NULL,
	`area_id` INT(10) NOT NULL,
	`dealer_name` VARCHAR(255) NOT NULL,
	`dealer_type` VARCHAR(255) NOT NULL,
	`address` TEXT NOT NULL,
	`phone` TEXT NOT NULL,
	PRIMARY KEY (`id`),
	INDEX `FK1_storelocator_category` (`category_id`),
	INDEX `FK2_storelocator_state` (`state_id`),
	INDEX `FK3_storelocator_city` (`city_id`),
	INDEX `FK4_storelocator_area` (`area_id`),
	CONSTRAINT `FK1_storelocator_category` FOREIGN KEY (`category_id`) REFERENCES `storelocator_category` (`id`) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT `FK2_storelocator_state` FOREIGN KEY (`state_id`) REFERENCES `storelocator_state` (`id`) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT `FK3_storelocator_city` FOREIGN KEY (`city_id`) REFERENCES `storelocator_city` (`id`) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT `FK4_storelocator_area` FOREIGN KEY (`area_id`) REFERENCES `storelocator_area` (`id`) ON UPDATE CASCADE ON DELETE CASCADE
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;

SQLTEXT;

$installer->run($sql);
//demo 
//Mage::getModel('core/url_rewrite')->setId(null);
//demo 
$installer->endSetup();
	 