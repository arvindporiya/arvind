<?php
class Coderzone_Storelocator_Block_Adminhtml_Storelocatorcategory_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("storelocator_form", array("legend"=>Mage::helper("storelocator")->__("Item information")));

				
						$fieldset->addField("name", "text", array(
						"label" => Mage::helper("storelocator")->__("Category Name"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "name",
						));
					
						$storeStates = Mage::getModel('storelocator/storelocatorstate')->getCollection();
				
						foreach ($storeStates as $storeState) {
						  $storeStateValues[] = array(
										'value'     => $storeState->getId(),
										'label'     => $storeState->getName()
									  );
						}

						$fieldset->addField('state_id','multiselect',	array(
								'name'   => 'state_id[]',
								"label" => Mage::helper("storelocator")->__("State"),					
								"class" => "required-entry",
								"required" => true,
								'value' => explode(',',Mage::registry("storelocatorcategory_data")->getStateId()),
								'values' => $storeStateValues,
						));

				if (Mage::getSingleton("adminhtml/session")->getStorelocatorcategoryData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getStorelocatorcategoryData());
					Mage::getSingleton("adminhtml/session")->setStorelocatorcategoryData(null);
				} 
				elseif(Mage::registry("storelocatorcategory_data")) {
				    $form->setValues(Mage::registry("storelocatorcategory_data")->getData());
				}
				return parent::_prepareForm();
		}
}
