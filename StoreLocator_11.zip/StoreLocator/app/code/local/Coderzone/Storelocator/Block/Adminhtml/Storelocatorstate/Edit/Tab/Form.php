<?php
class Coderzone_Storelocator_Block_Adminhtml_Storelocatorstate_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("storelocator_form", array("legend"=>Mage::helper("storelocator")->__("Item information")));

				
						$fieldset->addField("name", "text", array(
						"label" => Mage::helper("storelocator")->__("State"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "name",
						));
					
					$storeStates = Mage::getModel('storelocator/storelocatorcity')->getCollection();
				
						foreach ($storeStates as $storeState) {
						  $storeCityValues[] = array(
										'value'     => $storeState->getId(),
										'label'     => $storeState->getName()
									  );
						}

						$fieldset->addField('city_id','multiselect',	array(
								'name'   => 'city_id[]',
								"label" => Mage::helper("storelocator")->__("Select City"),					
								"class" => "required-entry",
								"required" => true,
								'value' => explode(',',Mage::registry("storelocatorstate_data")->getCityId()),
								'values' => $storeCityValues,
						));
				if (Mage::getSingleton("adminhtml/session")->getStorelocatorstateData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getStorelocatorstateData());
					Mage::getSingleton("adminhtml/session")->setStorelocatorstateData(null);
				} 
				elseif(Mage::registry("storelocatorstate_data")) {
				    $form->setValues(Mage::registry("storelocatorstate_data")->getData());
				}
				return parent::_prepareForm();
		}
}
