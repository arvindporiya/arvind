<?php
class Coderzone_Storelocator_Block_Adminhtml_Storelocatorcity_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("storelocator_form", array("legend"=>Mage::helper("storelocator")->__("Item information")));

				
						$fieldset->addField("name", "text", array(
						"label" => Mage::helper("storelocator")->__("City"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "name",
						));
					
						$storeArea = Mage::getModel('storelocator/storelocatorarea')->getCollection();
				
						foreach ($storeArea as $storeState) {
						  $storeAreaValues[] = array(
										'value'     => $storeState->getId(),
										'label'     => $storeState->getName()
									  );
						}

						$fieldset->addField('area_id','multiselect',	array(
								'name'   => 'area_id[]',
								"label" => Mage::helper("storelocator")->__("Select Area"),					
								"class" => "required-entry",
								"required" => true,
								'value' => explode(',',Mage::registry("storelocatorcity_data")->getAreaId()),
								'values' => $storeAreaValues,
						));
				if (Mage::getSingleton("adminhtml/session")->getStorelocatorcityData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getStorelocatorcityData());
					Mage::getSingleton("adminhtml/session")->setStorelocatorcityData(null);
				} 
				elseif(Mage::registry("storelocatorcity_data")) {
				    $form->setValues(Mage::registry("storelocatorcity_data")->getData());
				}
				return parent::_prepareForm();
		}
}
