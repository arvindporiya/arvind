<?php   
class Coderzone_Storelocator_Block_Index extends Mage_Core_Block_Template
{   
	public function getCategoryCollection()
    {
        return Mage::getModel("storelocator/storelocatorcategory")->getCollection();

    }
	
	public function getStateAction()
    {
         return $this->getUrl('storelocator/index/state', ['_secure' => true]);
    }
    public function getCityAction()
    {
         return $this->getUrl('storelocator/index/city', ['_secure' => true]);
    }
     public function getAreaAction()
    {
         return $this->getUrl('storelocator/index/area', ['_secure' => true]);
    }
}