<?php
class Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("storelocator_form", array("legend"=>Mage::helper("storelocator")->__("Item information")));

				// Store Category 
				/* $storeCategoryValues[] = array(
								'value'     => '0',
								'label'     => 'Please select'
							  ); */
							  
				$storeCategories = Mage::getModel('storelocator/storelocatorcategory')->getCollection();
				
				foreach ($storeCategories as $storeCategory) {
				  $storeCategoryValues[] = array(
								'value'     => $storeCategory->getId(),
								'label'     => $storeCategory->getName()
							  );
				}

				$fieldset->addField('category_id','multiselect',	array(
						'name'   => 'category_id',
						"label" => Mage::helper("storelocator")->__("Category Name"),					
						"class" => "required-entry",
						"required" => true,
						'values' => $storeCategoryValues,
				));
				
				// Store state 
				$storeStateValues[] = array(
								'value'     => '0',
								'label'     => 'Please select'
							  );
							  
				$storeStates = Mage::getModel('storelocator/storelocatorstate')->getCollection();
				
				foreach ($storeStates as $storeState) {
				  $storeStateValues[] = array(
								'value'     => $storeState->getId(),
								'label'     => $storeState->getName()
							  );
				}

				$fieldset->addField('state_id','select',	array(
						'name'   => 'state_id',
						"label" => Mage::helper("storelocator")->__("State"),					
						"class" => "required-entry",
						"required" => true,
						'values' => $storeStateValues,
				));
					
				
				// City state 
				$storeCityValues[] = array(
								'value'     => '0',
								'label'     => 'Please select'
							  );
							  
				$storeCities = Mage::getModel('storelocator/storelocatorcity')->getCollection();
				
				foreach ($storeCities as $storeCity) {
				  $storeCityValues[] = array(
								'value'     => $storeCity->getId(),
								'label'     => $storeCity->getName()
							  );
				}

				$fieldset->addField('city_id','select',	array(
						'name'   => 'city_id',
						"label" => Mage::helper("storelocator")->__("City"),					
						"class" => "required-entry",
						"required" => true,
						'values' => $storeCityValues,
				));

				// Area state 
				$storeAreaValues[] = array(
								'value'     => '0',
								'label'     => 'Please select'
							  );
							  
				$storeAreas = Mage::getModel('storelocator/storelocatorarea')->getCollection();
				
				foreach ($storeAreas as $storeArea) {
				  $storeAreaValues[] = array(
								'value'     => $storeArea->getId(),
								'label'     => $storeArea->getName()
							  );
				}

				$fieldset->addField('area_id','select',	array(
						'name'   => 'area_id',
						"label" => Mage::helper("storelocator")->__("Area"),					
						"class" => "required-entry",
						"required" => true,
						'values' => $storeAreaValues,
				));
				
				$fieldset->addField('dealer_name','text',	array(
						'name'   => 'dealer_name',
						"label" => Mage::helper("storelocator")->__("Dealer Name"),					
						"class" => "required-entry",
						"required" => true
				));
				
				$fieldset->addField('dealer_type','select',	array(
						'name'   => 'area_id',
						"label" => Mage::helper("storelocator")->__("Dealer Type"),					
						"class" => "required-entry",
						"required" => true,
						'values' => array('AUTHORIZED DEALER'=>'AUTHORIZED DEALER','EXCLUSIVE DEALER'=>'EXCLUSIVE DEALER')
				));
				
				/* $fieldset->addField('address','text',	array(
						'name'   => 'address',
						"label" => Mage::helper("storelocator")->__("Address"),					
						"class" => "required-entry",
						"required" => true
				)); */
				
				$fieldset->addField('phone','text',	array(
						'name'   => 'phone',
						"label" => Mage::helper("storelocator")->__("Phone"),					
						"class" => "required-entry",
						"required" => true
				));
				
				if (Mage::getSingleton("adminhtml/session")->getStorelocatorcategoryData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getStorelocatorcategoryData());
					Mage::getSingleton("adminhtml/session")->setStorelocatorcategoryData(null);
				} 
				elseif(Mage::registry("storelocatorbackend_data")) {
				    $form->setValues(Mage::registry("storelocatorbackend_data")->getData());
				}
				return parent::_prepareForm();
		}
}
