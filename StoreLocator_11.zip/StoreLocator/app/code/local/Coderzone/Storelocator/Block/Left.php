<?php   
class Coderzone_Storelocator_Block_Left extends Mage_Core_Block_Template{   





}