<?php  

class Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend extends Mage_Adminhtml_Block_Widget_Grid_Container {

	public function __construct()
	{

	$this->_controller = "adminhtml_storelocatorbackend";
	$this->_blockGroup = "storelocator";
	$this->_headerText = Mage::helper("storelocator")->__("Storelocatorbackend Manager");
	$this->_addButtonLabel = Mage::helper("storelocator")->__("Add New Item");
	parent::__construct();
	
	}
}