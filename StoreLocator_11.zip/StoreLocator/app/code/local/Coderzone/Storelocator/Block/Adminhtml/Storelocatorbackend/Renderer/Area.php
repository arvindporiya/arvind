<?php

class Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Renderer_Area extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
	public function render(Varien_Object $row) 
	{
		$areaId = $row->getAreaId();
		$value = Mage::getModel("storelocator/storelocatorarea")->load($areaId);
		return $value->getName();
	}
}