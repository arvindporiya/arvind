<?php
class Coderzone_Storelocator_IndexController extends Mage_Core_Controller_Front_Action{
    public function IndexAction() {
	  $this->loadLayout();   
	  $this->getLayout()->getBlock("head")->setTitle($this->__("Store Locator"));
	        $breadcrumbs = $this->getLayout()->getBlock("breadcrumbs");
      $breadcrumbs->addCrumb("home", array(
                "label" => $this->__("Home Page"),
                "title" => $this->__("Home Page"),
                "link"  => Mage::getBaseUrl()
		   ));

      $breadcrumbs->addCrumb("store locator", array(
                "label" => $this->__("Store Locator"),
                "title" => $this->__("Store Locator")
		   ));

      $this->renderLayout(); 
    }
	
	public function StateAction()
	{
		$category_id = $this->getRequest()->getParam('category_id');
		$stateModel = Mage::getModel("storelocator/storelocatorstate");
        $html='';            
        $html.='<option selected="selected" value="">Please Select Option</option>';
        if(!empty($category_id))
        { 
            $collection= Mage::getModel("storelocator/storelocatorcategory")->load($category_id);
			if($collection->getStateId()){
				$states = explode(',',$collection->getStateId());
				foreach ($states as $stateId) {
					$state = Mage::getModel("storelocator/storelocatorstate")->load($stateId);
					
					$html.="<option value=".$state->getId().">".$state->getName()."</option>";
				}
			}
        }
		$this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
        $this->getResponse()->setBody(json_encode(array('success' => true,'value'=>$html)));
	}
}









