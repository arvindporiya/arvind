<?php

class Coderzone_Storelocator_Adminhtml_StorelocatorcategoryController extends Mage_Adminhtml_Controller_Action
{
		protected function _isAllowed()
		{
		//return Mage::getSingleton('admin/session')->isAllowed('storelocator/storelocatorcategory');
			return true;
		}

		protected function _initAction()
		{
				$this->loadLayout()->_setActiveMenu("storelocator/storelocatorcategory")->_addBreadcrumb(Mage::helper("adminhtml")->__("Storelocatorcategory  Manager"),Mage::helper("adminhtml")->__("Storelocatorcategory Manager"));
				return $this;
		}
		public function indexAction() 
		{
			    $this->_title($this->__("Storelocator"));
			    $this->_title($this->__("Manager Storelocatorcategory"));

				$this->_initAction();
				$this->renderLayout();
		}
		public function editAction()
		{			    
			    $this->_title($this->__("Storelocator"));
				$this->_title($this->__("Storelocatorcategory"));
			    $this->_title($this->__("Edit Item"));
				
				$id = $this->getRequest()->getParam("id");
				$model = Mage::getModel("storelocator/storelocatorcategory")->load($id);
				if ($model->getId()) {
					Mage::register("storelocatorcategory_data", $model);
					$this->loadLayout();
					$this->_setActiveMenu("storelocator/storelocatorcategory");
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Storelocatorcategory Manager"), Mage::helper("adminhtml")->__("Storelocatorcategory Manager"));
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Storelocatorcategory Description"), Mage::helper("adminhtml")->__("Storelocatorcategory Description"));
					$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
					$this->_addContent($this->getLayout()->createBlock("storelocator/adminhtml_storelocatorcategory_edit"))->_addLeft($this->getLayout()->createBlock("storelocator/adminhtml_storelocatorcategory_edit_tabs"));
					$this->renderLayout();
				} 
				else {
					Mage::getSingleton("adminhtml/session")->addError(Mage::helper("storelocator")->__("Item does not exist."));
					$this->_redirect("*/*/");
				}
		}

		public function newAction()
		{

		$this->_title($this->__("Storelocator"));
		$this->_title($this->__("Storelocatorcategory"));
		$this->_title($this->__("New Item"));

        $id   = $this->getRequest()->getParam("id");
		$model  = Mage::getModel("storelocator/storelocatorcategory")->load($id);

		$data = Mage::getSingleton("adminhtml/session")->getFormData(true);
		if (!empty($data)) {
			$model->setData($data);
		}

		Mage::register("storelocatorcategory_data", $model);

		$this->loadLayout();
		$this->_setActiveMenu("storelocator/storelocatorcategory");

		$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Storelocatorcategory Manager"), Mage::helper("adminhtml")->__("Storelocatorcategory Manager"));
		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Storelocatorcategory Description"), Mage::helper("adminhtml")->__("Storelocatorcategory Description"));


		$this->_addContent($this->getLayout()->createBlock("storelocator/adminhtml_storelocatorcategory_edit"))->_addLeft($this->getLayout()->createBlock("storelocator/adminhtml_storelocatorcategory_edit_tabs"));

		$this->renderLayout();

		}
		public function saveAction()
		{

			$post_data=$this->getRequest()->getPost();


				if ($post_data) {
					
					try {
						if(isset($post_data) && $post_data){
							$post_data['state_id'] = implode(',',$post_data['state_id']);
						}
						$model = Mage::getModel("storelocator/storelocatorcategory")
						->addData($post_data)
						->setId($this->getRequest()->getParam("id"))
						->save();

						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Storelocatorcategory was successfully saved"));
						Mage::getSingleton("adminhtml/session")->setStorelocatorcategoryData(false);

						if ($this->getRequest()->getParam("back")) {
							$this->_redirect("*/*/edit", array("id" => $model->getId()));
							return;
						}
						$this->_redirect("*/*/");
						return;
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						Mage::getSingleton("adminhtml/session")->setStorelocatorcategoryData($this->getRequest()->getPost());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					return;
					}

				}
				$this->_redirect("*/*/");
		}



		public function deleteAction()
		{
				if( $this->getRequest()->getParam("id") > 0 ) {
					try {
						$model = Mage::getModel("storelocator/storelocatorcategory");
						$model->setId($this->getRequest()->getParam("id"))->delete();
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
						$this->_redirect("*/*/");
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					}
				}
				$this->_redirect("*/*/");
		}

		
		public function massRemoveAction()
		{
			try {
				$ids = $this->getRequest()->getPost('ids', array());
				foreach ($ids as $id) {
                      $model = Mage::getModel("storelocator/storelocatorcategory");
					  $model->setId($id)->delete();
				}
				Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
			}
			catch (Exception $e) {
				Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
			}
			$this->_redirect('*/*/');
		}
			
		/**
		 * Export order grid to CSV format
		 */
		public function exportCsvAction()
		{
			$fileName   = 'storelocatorcategory.csv';
			$grid       = $this->getLayout()->createBlock('storelocator/adminhtml_storelocatorcategory_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
		} 
		/**
		 *  Export order grid to Excel XML format
		 */
		public function exportExcelAction()
		{
			$fileName   = 'storelocatorcategory.xml';
			$grid       = $this->getLayout()->createBlock('storelocator/adminhtml_storelocatorcategory_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
		}
}
