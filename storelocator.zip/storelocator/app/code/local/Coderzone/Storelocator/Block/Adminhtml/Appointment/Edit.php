<?php
class Shadtechz_Appointment_Block_Adminhtml_Appointment_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    /**
     * Init class
     */
    public function __construct()
    {  
        $this->_blockGroup = 'appointment';
        $this->_controller = 'adminhtml_appointment';
     
        parent::__construct();
     
        $this->_updateButton('save', 'label', $this->__('Save Appointment'));
        $this->_updateButton('delete', 'label', $this->__('Delete Appointment'));
    }  
     
    /**
     * Get Header text
     *
     * @return string
     */
    public function getHeaderText()
    {  
        if (Mage::registry('appointment_data')->getId()) {
            return $this->__('Edit Appointment');
        }  
        else {
            return $this->__('New Appointment');
        }  
    }  
}