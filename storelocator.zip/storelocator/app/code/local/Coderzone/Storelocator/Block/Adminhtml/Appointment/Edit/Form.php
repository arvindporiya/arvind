<?php
class Shadtechz_Appointment_Block_Adminhtml_Appointment_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
    /**
     * Init class
     */
    public function __construct()
    {  
        parent::__construct();
     
        $this->setId('appointment_form');
        $this->setTitle($this->__('Appointment Information'));
    }  
     
    /**
     * Setup form fields for inserts/updates
     *
     * return Mage_Adminhtml_Block_Widget_Form
     */
    protected function _prepareForm()
    {  
        $model = Mage::registry('appointment_data');
		//echo $this->getRequest()->getParam('id'); exit;
        $form = new Varien_Data_Form(array(
            'id'        => 'edit_form',
            'action'    => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
            'method'    => 'post'
        ));
     
        $fieldset = $form->addFieldset('base_fieldset', array(
            'legend'    => Mage::helper('appointment')->__('Appointment Information'),
            'class'     => 'fieldset-wide',
        ));
     
        if ($model->getId()) {
            $fieldset->addField('appointment_id', 'hidden', array(
                'name' => 'appointment_id',
            ));
        }  
     
        $fieldset->addField(
            'name',
            'text',
            array(
                'label' => Mage::helper('appointment')->__('Customer Name'),
                'name'  => 'name',
            )
        );
		
		$fieldset->addField(
            'email',
            'text',
            array(
                'label' => Mage::helper('appointment')->__('Customer Email'),
                'name'  => 'email',
            )
        );
		
		$fieldset->addField(
            'address',
            'text',
            array(
                'label' => Mage::helper('appointment')->__('Address'),
                'name'  => 'address',
            )
        );
		
		$fieldset->addField(
            'contact',
            'text',
            array(
                'label' => Mage::helper('appointment')->__('Contact No'),
                'name'  => 'contact',
            )
        );
		
		$fieldset->addField(
            'appointment_date',
            'text',
            array(
                'label' => Mage::helper('appointment')->__('Appointment Date'),
                'name'  => 'appointment_date',
            )
        );
		
		$fieldset->addField(
            'location',
            'text',
            array(
                'label' => Mage::helper('appointment')->__('Location'),
                'name'  => 'location',
            )
        );
		
		$fieldset->addField(
            'location_fees',
            'text',
            array(
                'label' => Mage::helper('appointment')->__('Location Fees'),
                'name'  => 'location_fees',
            )
        );
	
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }  
}