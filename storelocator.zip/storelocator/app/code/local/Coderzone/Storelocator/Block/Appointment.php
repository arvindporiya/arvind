<?php
class Shadtechz_Appointment_Block_Appointment extends Mage_Core_Block_Template
{
	/* debuging handles */
	public function _debugHandles(){
		var_dump( Zend_Debug::dump($this->getLayout()->getUpdate()->getHandles()) );
	}
}