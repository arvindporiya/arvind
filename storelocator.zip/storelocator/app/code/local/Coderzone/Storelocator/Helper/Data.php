<?php

class Coderzone_Storelocator_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function adminEmail()
    {
		$email = Mage::getStoreConfig('email_options/app_group/app_admin_email',Mage::app()->getStore());
		if(isset($email) && !empty($email)){
			return $email;
		}else{
			return 'arvindporiya92@gmail.com';
		}
    }
}