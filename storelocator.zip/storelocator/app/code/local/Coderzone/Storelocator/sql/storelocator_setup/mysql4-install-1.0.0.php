<?php

$installer = $this;
 
$installer->startSetup();
 
$installer->run("

CREATE TABLE IF NOT EXISTS storelocator (
   storelocator_id  int(11) NOT NULL auto_increment,
   `entity_id` int(11) NOT NULL,
   `state_id` int(11) NOT NULL,
   `city_id` int(11) NOT NULL,
   `area_id` int(11) NOT NULL,
   `seller_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (appointment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    ");
$installer->getConnection()
    ->addForeignKey(
        $installer->getFkName('storelocator', 'product_id', 'catalog_product_entity','entity_id'),
        $installer->getTable('storelocator'),
        $installer->getTable('catalog_product_entity'), 
        'entity_id',
        Varien_Db_Ddl_Table::ACTION_CASCADE, 
        Varien_Db_Ddl_Table::ACTION_CASCADE
    )  
$installer->endSetup();