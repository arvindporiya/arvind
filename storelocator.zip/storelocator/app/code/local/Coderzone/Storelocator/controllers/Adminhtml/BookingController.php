<?php

class Shadtechz_Appointment_Adminhtml_BookingController extends Mage_Adminhtml_Controller_Action {
    
	protected function _initAction() {
        $this->loadLayout()->_setActiveMenu('appointment')
						   ->_title($this->__('Appointment'));
        return $this;
    }
	
	protected function _isAllowed(){
		return Mage::getSingleton('admin/session')->isAllowed('appointment');
	}

    public function indexAction() 
	{
        $this->_initAction();
        $this->_addContent($this->getLayout()->createBlock('appointment/adminhtml_appointment'));
        $this->renderLayout();
    }
	
	public function saveAction()
    {
		$data = $this->getRequest()->getPost();
		$model = Mage::getModel('appointment/appointment')->load($data['appointment_id']);
        if ($data && $model->getId()) 
		{
            try {
				$dates = $data['appointment_date'];
				$date = date('Y-m-d', strtotime($dates));
				$today = date('Y-m-d', strtotime(now()));
				
				if(strtotime($date) == strtotime($today))
				{
					Mage::getSingleton('adminhtml/session')->addError($this->__('Appointment not book '.$data['appointment_date'].' date'));
					$this->_redirect('*/*/edit',array('id' => $data['appointment_id'],'_current'=>true));
					return;
				}
				
				$collection = $model->getCollection()->addFieldToFilter('appointment_date',array('eq'=>$date));
				if($collection->getSize() > 3){
					Mage::getSingleton('adminhtml/session')->addError($this->__('Appointment full booked on '.$data['appointment_date'].'.'));
					$this->_redirect('*/*/edit',array('id' => $data['appointment_id'],'_current'=>true));
					return;
				}
				
				$model->setData($data);
                $model->save();
 
                Mage::getSingleton('adminhtml/session')->addSuccess($this->__('The Appointment has been saved.'));
                $this->_redirect('*/*/');
 
                return;
            }  
            catch (Mage_Core_Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
            catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($this->__('An error occurred while saving this Appointment.'));
            }
 
            Mage::getSingleton('adminhtml/session')->setAppointmentData($data);
            $this->_redirectReferer();
        }else{
			Mage::getSingleton('adminhtml/session')->addError(Mage::helper('core')->__('This Appointment no longer exists.'));
			$this->_redirect('*/*/edit',array('id' => $data['appointment_id'],'_current'=>true));
			return;
		}
    }
	
	public function deleteAction()
    {
        if(!$id = $this->getRequest()->getParam('id')) {
			Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select reqeust(s)'));
		} else {
			try {
				$model = Mage::getModel('appointment/appointment');
				$model->load($id);
				if (!$model->getId()) {
					Mage::throwException(Mage::helper('appointment')->__('Unable to find a Appointment.'));
				}
				$model->delete();           
				Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Appointment were successfully deleted'));
			} catch (Exception $e) {
				Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
			}
		}
		$this->_redirect('*/*/');
    }

	
	
	public function editAction()
    {  
        $this->_initAction();
     
        // Get id if available
        $id  = $this->getRequest()->getParam('id');
        $model = Mage::getModel('appointment/appointment');
     
        if ($id) {
            // Load record
            $model->load($id);
            // Check if record is loaded
            if (!$model->getId()) {
                Mage::getSingleton('adminhtml/session')->addError($this->__('This Appointment no longer exists.'));
                $this->_redirect('*/*/');
                return;
            }  
        }  
     
        $this->_title($this->__('Appointment Edit'));
     
        $data = Mage::getSingleton('adminhtml/session')->getAppointmentData(true);
        if (!empty($data)) {
            $model->setData($data);
        }  
     
        Mage::register('appointment_data', $model);
        $this->_initAction()
            ->_addBreadcrumb($id ? $this->__('Edit Appointment') : $this->__('New Appointment'), $id ? $this->__('Edit Appointment') : $this->__('New Appointment'))
            ->_addContent($this->getLayout()->createBlock('appointment/adminhtml_appointment_edit')->setData('action', $this->getUrl('*/*/save')))
            ->renderLayout();
    }
	
	public function massDeleteAction() 
	{
		$requestIds = $this->getRequest()->getParam('appointment_id');
		if(!is_array($requestIds)) {
			Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select reqeust(s)'));
		} else {
			try {
				foreach ($requestIds as $requestId) {
					$model = Mage::getModel('appointment/appointment');
					$model->load($requestId);
					if (!$model->getId()) {
						Mage::throwException(Mage::helper('appointment')->__('Unable to find a Appointment.'));
					}
					$model->delete();                    
				}
				Mage::getSingleton('adminhtml/session')->addSuccess(
					Mage::helper('adminhtml')->__(
						'Total of %d record(s) were successfully deleted', count($requestIds)
					)
				);
			} catch (Exception $e) {
				Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
			}
		}
		$this->_redirect('*/*/');
	}
}