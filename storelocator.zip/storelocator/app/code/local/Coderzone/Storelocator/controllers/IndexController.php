<?php
class Shadtechz_Appointment_IndexController extends Mage_Core_Controller_Front_Action
{
	
	public function indexAction(){
		$this->loadLayout();
        $this->renderLayout();
	}
	
	public function saveAction()
	{
		$data = Mage::app()->getRequest()->getPost();
		
		if($data){
			try {
				$model  = Mage::getModel('appointment/appointment');
				if($data['location'] == 'Ajman' || $data['location'] == 'Al Ain')
				{
					$data['location_fees'] = '200 AED';
				}else{
					$data['location_fees'] = 'Free';
				}
				$dates = $data['appointment_date'];
				$date = date('Y-m-d', strtotime($dates));
				$today = date('Y-m-d', strtotime(now()));
				
				if(strtotime($date) < strtotime($today)){
					Mage::getSingleton('core/session')->addError(Mage::helper('core')->__('Please Enter correct appointment date'));
					$this->_redirect('*/*/');
					return;
				}

				if(strtotime($date) == strtotime($today)){
					Mage::getSingleton('core/session')->addError(Mage::helper('core')->__('Appointment not book '.$data['appointment_date'].' date'));
					$this->_redirect('*/*/');
					return;
				}
				
				$collection = $model->getCollection()->addFieldToFilter('appointment_date',array('eq'=>$date));
				if($collection->getSize() > 3){
					Mage::getSingleton('core/session')->addError(Mage::helper('core')->__('Appointment full booked on '.$data['appointment_date'].'.'));
					$this->_redirect('*/*/');
					return;
				}
				$model->setData($data)
					  ->save();
				Mage::helper('appointment')->appointmentMail($model); 
				Mage::getSingleton('core/session')->addSuccess(Mage::helper('core')->__('Your Appointment was submitted and will be responded to as soon as possible. Thank you for contacting us.'));
				$this->_redirect('appointment/index/success');
			} catch (Exception $e) {
				Mage::getSingleton('core/session')->addError(Mage::helper('core')->__($e->getMessage()));
				$this->_redirect('*/*/');
				return;
			}
		}else {
			$this->_redirect('*/*/');
		}
	}
	
	public function datecheckAction()
	{
		$date = $this->getRequest()->getParam('ap_date');
		$model  = Mage::getModel('appointment/appointment');
		$data['message'] = '';
		$data['class'] = '';
		if($date){
			$dates = date('Y-m-d', strtotime($date));
			$today = date('Y-m-d', strtotime(now()));
			
			if(strtotime($dates) < strtotime($today)){
					$data['message'] = Mage::helper('core')->__("It's not valid date,Please Enter correct appointment date");
					$data['class'] = 'message-error error message';
			}else{
				$collection = $model->getCollection()->addFieldToFilter('appointment_date',array('eq'=>$dates));
				if($collection->getSize() > 3)
				{
					$data['message'] = Mage::helper('core')->__('Appointment full booked on '.$date.'. Please Select another date');
					$data['class'] = 'message-error error message';
				}
			}
		}
		
		$response = ['message' => $data['message'],'class' => $data['class']];
		$this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
        $this->getResponse()->setBody(json_encode($response));
	}
	
	public function successAction(){
		$this->loadLayout();
		$block = $this->getLayout()->createBlock('core/template');
		$block->setTemplate('shadtechz_appointment/success.phtml');
		$this->getLayout()->getBlock('content')->append($block);
		$this->renderLayout();
	}
}