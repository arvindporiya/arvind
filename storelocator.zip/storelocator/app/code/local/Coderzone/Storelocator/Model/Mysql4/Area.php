<?php
 
class Coderzone_Storelocator_Model_Mysql4_Area extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {   
        $this->_init( 'storelocator/area', 'area_id' );
    }
}