<?php
 
class Coderzone_Storelocator_Model_Mysql4_State extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {   
        $this->_init( 'storelocator/state', 'state_id' );
    }
}