<?php
class Coderzone_Storelocator_IndexController extends Mage_Core_Controller_Front_Action{
    public function IndexAction() {
	  $this->loadLayout();   
	  $this->getLayout()->getBlock("head")->setTitle($this->__("Store Locator"));
	        $breadcrumbs = $this->getLayout()->getBlock("breadcrumbs");
      $breadcrumbs->addCrumb("home", array(
                "label" => $this->__("Home Page"),
                "title" => $this->__("Home Page"),
                "link"  => Mage::getBaseUrl()
		   ));

      $breadcrumbs->addCrumb("store locator", array(
                "label" => $this->__("Store Locator"),
                "title" => $this->__("Store Locator")
		   ));

      $this->renderLayout(); 
    }
	
	public function StateAction()
	{
		$category_id = $this->getRequest()->getParam('category_id');
        $html='';            
        $html.='<option selected="selected" value="">Please Select Option</option>';
        if(!empty($category_id))
        { 
            $collection= Mage::getModel("storelocator/storelocatorcategory")->load($category_id);
			if($collection->getStateId()){
				$states = explode(',',$collection->getStateId());
				foreach ($states as $stateId) {
					$state = Mage::getModel("storelocator/storelocatorstate")->load($stateId);
					$html.="<option value=".$state->getId().">".$state->getName()."</option>";
				}
			}
        }
		$this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
        $this->getResponse()->setBody(json_encode(array('success' => true,'value'=>$html)));
	}
	
	public function CityAction()
	{
        $state_id=$this->getRequest()->getParam('state_id');
        $html='';            
        $html.='<option selected="selected" value="">Please Select Option</option>';
        if(!empty($state_id))
        {
            $collection= Mage::getModel("storelocator/storelocatorstate")->load($state_id);
			if($collection->getCityId()){
				$cityIds = explode(',',$collection->getCityId());
				foreach ($cityIds as $cityId) {
					$city = Mage::getModel("storelocator/storelocatorcity")->load($cityId);
					$html.="<option value=".$city->getId().">".$city->getName()."</option>";
				}
			}
        }
		$this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
        $this->getResponse()->setBody(json_encode(array('success' => true,'value'=>$html)));
	}
	
	public function AreaAction()
	{
        $city_id=$this->getRequest()->getParam('city_id');
        $html='';            
        $html.='<option selected="selected" value="">Please Select Option</option>';
        if(!empty($city_id))
        {
            $collection= Mage::getModel("storelocator/storelocatorcity")->load($city_id);
			if($collection->getAreaId()){
				$areaIds = explode(',',$collection->getAreaId());
				foreach ($areaIds as $areaId) {
					$area = Mage::getModel("storelocator/storelocatorarea")->load($areaId);
					$html.="<option value=".$area->getId().">".$area->getName()."</option>";
				}
			}
        }
		$this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
        $this->getResponse()->setBody(json_encode(array('success' => true,'value'=>$html)));
	}
	
	public function StorelocateAction()
	{
        $city_id = $this->getRequest()->getParams();
		echo '<pre>';
		print_r($city_id);
		exit;
        $html='';            
        $html.='<option selected="selected" value="">Please Select Option</option>';
        if(!empty($city_id))
        {
            $collection= Mage::getModel("storelocator/storelocatorcity")->load($city_id);
			if($collection->getAreaId()){
				$areaIds = explode(',',$collection->getAreaId());
				foreach ($areaIds as $areaId) {
					$area = Mage::getModel("storelocator/storelocatorarea")->load($areaId);
					$html.="<option value=".$area->getId().">".$area->getName()."</option>";
				}
			}
        }
		$this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
        $this->getResponse()->setBody(json_encode(array('success' => true,'value'=>$html)));
	}
}









