<?php
class Coderzone_Storelocator_Model_Mysql4_Storelocatorarea extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("storelocator/storelocatorarea", "id");
    }
}