<?php
    class Coderzone_Storelocator_Model_Mysql4_Storelocatorcity_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("storelocator/storelocatorcity");
		}

		

    }
	 