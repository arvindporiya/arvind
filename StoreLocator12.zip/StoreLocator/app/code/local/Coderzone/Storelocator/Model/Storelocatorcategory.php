<?php

class Coderzone_Storelocator_Model_Storelocatorcategory extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("storelocator/storelocatorcategory");

    }

}
	 