<?php

class Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

		public function __construct()
		{
				parent::__construct();
				$this->setId("storelocatorbackendGrid");
				$this->setDefaultSort("id");
				$this->setDefaultDir("DESC");
				$this->setSaveParametersInSession(true);
		}

		protected function _prepareCollection()
		{
				$collection = Mage::getModel("storelocator/storelocatorbackend")->getCollection();
				$this->setCollection($collection);
				return parent::_prepareCollection();
		}
		protected function _prepareColumns()
		{
			/* $this->addColumn('dropdown', array(
				'header' => Mage::helper('catalog')->__('Dropdown'),
				'filter'    => false,
				'sortable'  => false,
				'type'=> 'options',
				'options' => array('First'=>'firstvalue', 'second' =>'secondvalue')
			)); */
			
			$this->addColumn("id", array(
				"header" => Mage::helper("storelocator")->__("ID"),
				"align" =>"right",
				"width" => "50px",
			    "type" => "number",
				"index" => "id",
			));
			
			$this->addColumn('address', array(
				'header' => Mage::helper('catalog')->__('Address'),
				'filter'    => false,
				'sortable'  => false,
				'index' => 'address'
			));
			
			$this->addColumn('phone', array(
				'header' => Mage::helper('catalog')->__('Phone'),
				'filter'    => false,
				'sortable'  => false,
				'index' => 'phone'
			));
			
			$this->addColumn('category_id', array(
				'header' => Mage::helper('catalog')->__('Category Name'),
				//'filter'    => false,
				//'sortable'  => false,
				'index' => 'category_id',
				'renderer' => 'Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Renderer_Categories',
			));
			
			$this->addColumn('state_id', array(
				'header' => Mage::helper('catalog')->__('State'),
				//'filter'    => false,
				//'sortable'  => false,
				'index' => 'state_id',
				'renderer' => 'Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Renderer_State',
			));
			$this->addColumn('city_id', array(
				'header' => Mage::helper('catalog')->__('City'),
				//'filter'    => false,
				//'sortable'  => false,
				'index' => 'city_id',
				'renderer' => 'Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Renderer_City',
			));
			$this->addColumn('area_id', array(
				'header' => Mage::helper('catalog')->__('Area'),
				//'filter'    => false,
				//'sortable'  => false,
				'index' => 'area_id',
				'renderer' => 'Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Renderer_Area',
			));
                
			$this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV')); 
			$this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

				return parent::_prepareColumns();
		}

		public function getRowUrl($row)
		{
			   return $this->getUrl("*/*/edit", array("id" => $row->getId()));
		}


		
		protected function _prepareMassaction()
		{
			$this->setMassactionIdField('id');
			$this->getMassactionBlock()->setFormFieldName('ids');
			$this->getMassactionBlock()->setUseSelectAll(true);
			$this->getMassactionBlock()->addItem('remove_storelocatorbackend', array(
					 'label'=> Mage::helper('storelocator')->__('Remove Storelocatorcategory'),
					 'url'  => $this->getUrl('*/adminhtml_storelocatorbackend/massRemove'),
					 'confirm' => Mage::helper('storelocator')->__('Are you sure?')
				));
			return $this;
		}
			

}