<?php
class Coderzone_Storelocator_Block_Adminhtml_Storelocatorarea_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("storelocator_form", array("legend"=>Mage::helper("storelocator")->__("Item information")));

				
						$fieldset->addField("name", "text", array(
						"label" => Mage::helper("storelocator")->__("Area"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "name",
						));
					

				if (Mage::getSingleton("adminhtml/session")->getStorelocatorareaData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getStorelocatorareaData());
					Mage::getSingleton("adminhtml/session")->setStorelocatorareaData(null);
				} 
				elseif(Mage::registry("storelocatorarea_data")) {
				    $form->setValues(Mage::registry("storelocatorarea_data")->getData());
				}
				return parent::_prepareForm();
		}
}
