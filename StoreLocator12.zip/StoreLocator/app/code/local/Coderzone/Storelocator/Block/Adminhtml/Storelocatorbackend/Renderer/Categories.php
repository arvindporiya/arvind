<?php

class Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Renderer_Categories extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
	public function render(Varien_Object $row) 
	{
		$categoryId = $row->getCategoryId();
		$value = Mage::getModel("storelocator/storelocatorcategory")->load($categoryId);
		return $value->getName();
	}
}