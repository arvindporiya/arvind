<?php

class Coderzone_Storelocator_Block_Adminhtml_Storelocatorbackend_Renderer_State extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
	public function render(Varien_Object $row) 
	{
		$stateId = $row->getStateId();
		$value = Mage::getModel("storelocator/storelocatorstate")->load($stateId);
		return $value->getName();
	}
}